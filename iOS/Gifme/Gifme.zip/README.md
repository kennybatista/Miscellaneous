# Instructions
Gifme should be a simple Gif sharing app, but it's buggy as hell :( It doesn't even build! :O
- You can find 2 sample images "cats.png" and "dogs.png" to see what the app _should_ look like.
- Please spend no more than an hour--your time is valuable, and we respect that--fixing whatever bugs you can find in the app.
 - There are about 10 bugs scattered throughout the app. Some are more important than others.

# gifme
Gifme is a GIF sharing app for iOS. It is not intened for App Store use. 

# Thanks To
Giphy.com for the API (Powered by Giphy)
Gifu for the Native gif renderer 

# Copyright
The MIT License (MIT)

Copyright (c) 2015 BuzzFeed, Inc

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
