import UIKit
/// Makes `UIImageView` conform to `ImageContainer`
extension UIImageView: ImageContainer {}
