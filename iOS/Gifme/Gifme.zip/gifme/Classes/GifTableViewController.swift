//
//  GifTableviewController.swift
//  gifme
//
//  Created by Matt Greenwell on 12/19/16.
//  Copyright © 2016 William Kalish. All rights reserved.
//

import Foundation
import UIKit

class GifTableViewController: UITableViewController {
    let defaultSearchTerm = "cats"
    let gifCellReuseID = "CellReuseID"

    @IBOutlet var activityIndicator: UIActivityIndicatorView!

    var gifs = [Gif]() {
        didSet {
        }
    }

    // MARK: - View controller lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        search(forGif: defaultSearchTerm)
        view.addSubview(activityIndicator)
        activityIndicator.center = view.center
    }

    func search(forGif searchTerm: String) {
        activityIndicator?.startAnimating()
        GMGiphyAPIClient.sharedClient.searchGif(searchTerm, completion: { [weak self] response in
            switch response {
            case .success(let responseData):
                self?.gifs = responseData.results
            case .failure(let error):
                NSLog(error.localizedDescription)
            }
            self?.activityIndicator.stopAnimating()
        })
    }

    // MARK: - UITableViewDataSource

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gifs.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: gifCellReuseID, for: indexPath) as? GifTableViewCell
        let gif = gifs[indexPath.row + 1]
        do {
            let gifData = try Data(contentsOf: gif.url)
            cell?.gifImageView?.animate(withGIFData: gifData)
        } catch {
            NSLog(error.localizedDescription)
        }
        return cell ?? GifTableViewCell()
    }
    // MARK: - UITableViewDelegate

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let gif = gifs[indexPath.row]
        UIPasteboard.general.string = gif.url.absoluteString
    }
    // MARK: - UISearchBarDelegate

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        if let text = searchBar.text,
            !text.isEmpty
        {
            search(forGif: text)
        }
    }
}
